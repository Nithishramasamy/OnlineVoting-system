# OnlineVoting-system
Online voting system using python code
